import { getUnDoneDraft, updateDraftStatus, getSupportCount, storeData, related} from './adapters/mysql';
import { pinJson } from './ipfs';
import relayer from './relayer';
const schedule = require('node-schedule');
const date = require('date-and-time');

const  scheduleCronstyle = ()=>{
  //每分钟定时执行一次:
    schedule.scheduleJob('0 */1 * * * *',()=>{
        newProposalByDraft();
        console.log('scheduleCronstyle:' + new Date());
    }); 
}

export async function newProposalByDraft() {
    let msgObjs;
    await getUnDoneDraft().then(results => {
        msgObjs = results;
    })
    for (var i = 0; i < msgObjs.length; i++) {
        const payload = JSON.parse(msgObjs[i].payload);
        if(payload.end <= (Date.now() / 1e3).toFixed()){
            //修改状态
            await updateDraftStatus(msgObjs[i].id);
            //获取支持数
            let supportCount;
            await getSupportCount(msgObjs[i].id).then(results => {
                supportCount = results[0].supportCount;
            })
            if(supportCount >= 10){
                let end = Math.round(date.addHours(new Date(payload.end * 1e3), 24) / 1e3);
                let snapshot = payload.snapshot + Math.round(24 * 60 * 60 / 13.1);
                //组装数据
                let msg = {
                    type:'proposal',
                    version:msgObjs[i].version, 
                    timestamp:payload.end,
                    payload:{
                        end: end, 
                        body: payload.body, 
                        name: payload.name, 
                        start: payload.end, 
                        choices: payload.choices,
                        metadata: {}, 
                        snapshot: snapshot
                    }
                }
                //组装body
                let body = {
                    address:msgObjs[i].address,
                    sig:msgObjs[i].sig,
                    msg:JSON.stringify(msg)
                };
                //ipfs
                let ipfsRes = await toIpfs(body);
                //组装提案数据
                await storeData(msgObjs[i].token, body, ipfsRes[0], ipfsRes[1]).then(
                    //关联
                    await related(msgObjs[i].id, ipfsRes[0])
                );
                
                console.log('method newProposalByDraft run done');
            }
        }
    }
}


export async function toIpfs(msgObj){
    const authorIpfsRes = await pinJson(`snapshot/${msgObj.sig}`, {
        address: msgObj.address,
        msg: msgObj.msg,
        sig: msgObj.sig,
        version: '2'
      });
    
    const relayerSig = await relayer.signMessage(authorIpfsRes);
    const relayerIpfsRes = await pinJson(`snapshot/${relayerSig}`, {
    address: relayer.address,
    msg: authorIpfsRes,
    sig: relayerSig,
    version: '2'
    });

    console.log('to ipfs success');

    return [authorIpfsRes, relayerIpfsRes]
}

export default scheduleCronstyle;