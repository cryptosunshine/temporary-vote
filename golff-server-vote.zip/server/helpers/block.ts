const date = require('date-and-time');
var Web3 = require('web3');
const web3 = new Web3();
const provider = web3.setProvider("https://mainnet.infura.io/v3/cd7b17dab52045fa86211dbfad351bbf");

export async function getBlockNumber() {
    const start = Math.round(Date.now() / 1e3);
    const end = Math.round(date.addHours(new Date(start * 1e3), 48) / 1e3);
    let snapshot = await web3.eth.getBlockNumber();
    snapshot = snapshot + Math.round(48 * 60 * 60 / 13.1);
    return [start, end, snapshot];
}

export default getBlockNumber;