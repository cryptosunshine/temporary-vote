var uuidV1 = require('uuidv1');
var greenNodejs = require('./green-nodejs-invoker.js');

const accessKeyId = 'LTAI4FcZeBuBsKqT95ztmyJ4';
const accessKeySecret = 'ncqOUScCclBogbO11eeE561RCoIVea';
const greenVersion = '2017-01-12';
var hostname = 'green.cn-shanghai.aliyuncs.com';
var path = '/green/text/scan';

var clientInfo = {
	"ip":"127.0.0.1"
};

var bizCfg = {
	'accessKeyId' : accessKeyId,
	'accessKeySecret' : accessKeySecret,
	'path' : path,
	'clientInfo' : clientInfo,
	'hostname' : hostname,
	'greenVersion' : greenVersion
}

export async function checkText(content) {
	// 请求体,根据需要调用相应的算法
	var requestBody = JSON.stringify({  
		bizType:'Green',
		scenes:['antispam'],
		tasks:[{
			'dataId':uuidV1(),
			'content':content
		}]
	}); 

	bizCfg.requestBody = requestBody;
    return new Promise((resolve, reject) => {
        greenNodejs(bizCfg, (chunk) => {
            if(!chunk){
                reject('error')
            }
            let results = JSON.parse(chunk);
            let s = results.data[0].results[0].suggestion;
            resolve(s)
        });
    });
	
}


