import db from '../mysql';
const date = require('date-and-time');

export async function storeData(space, body, authorIpfsHash, relayerIpfsHash) {
  const msg = JSON.parse(body.msg);
  let query = 'INSERT IGNORE INTO messages SET ?;';
  await db.queryAsync(query, [{
    id: authorIpfsHash,
    address: body.address,
    version: msg.version,
    timestamp: msg.timestamp,
    status:0,
    token: space,
    type: msg.type,
    payload: JSON.stringify(msg.payload),
    sig: body.sig,
    metadata: JSON.stringify({
      relayer_ipfs_hash: relayerIpfsHash
    })
  }]);
}

export async function getUnDoneDraft() {
  let query = `SELECT * FROM messages WHERE type = 'draft' AND status = 0 ORDER BY timestamp ASC`;
  return await db.queryAsync(query, []);
}

export async function getSupportCount(draftId) {
  let query = `SELECT COUNT(*) AS 'supportCount' FROM messages WHERE type = 'support' AND JSON_EXTRACT(payload, "$.draft") = ?`;
  return await db.queryAsync(query, [draftId]);
}

export async function getCommentCount(draftId) {
  let query = `SELECT COUNT(*) AS 'commentCount' FROM messages WHERE type = 'comment' AND status <> 2 AND JSON_EXTRACT(payload, "$.draft") = ?`;
  return await db.queryAsync(query, [draftId]);
}

export async function getProposalCommentCount(proposalId) {
  let query = `SELECT COUNT(*) AS 'commentCount' FROM messages WHERE type = 'comment' AND status <> 2 AND JSON_EXTRACT(payload, "$.proposal") = ?`;
  return await db.queryAsync(query, [proposalId]);
}

export async function updateDraftStatus(draftId) {
  let query = `UPDATE messages SET status = 1 WHERE id = ? AND status = 0`;
  await db.queryAsync(query, [draftId]).then(results => {
    console.log('update draft status success');
  })
}

export async function hideData(draftId) {
  let query = `UPDATE messages SET status = 2 WHERE id = ?`;
  return await db.queryAsync(query, [draftId]);
}

export async function related(draftId, proposalId) {
  let query = `UPDATE messages SET related = ? WHERE id = ?`;
  return await db.queryAsync(query, [proposalId, draftId]);
}

export async function checkSafety(address){
  let past = Math.round(date.addHours(new Date(), -24) / 1e3);
  let query = `SELECT COUNT(*) AS 'safetyCount' FROM messages WHERE address = ? AND timestamp >= ?`;
  return await db.queryAsync(query, [address, past]);
}

export async function getPagination(req, sql, param) {
  let pageNum = 1;
  let pageSize = 10;
  //分页查询字符串
  if(req.query){
    if(req.query.pageNum){
      pageNum = req.query.pageNum;
    }
    if(req.query.pageSize){
      pageSize = req.query.pageSize;
    }
  }
  const sqlPrefix = `SELECT COUNT(*) AS 'totalCount' `;
  const index = sql.indexOf(` ORDER BY`);
  let newSql = sql.substr(0, index);
  newSql = newSql.replace(`SELECT * `, sqlPrefix);
  let results = await db.queryAsync(newSql, param);
  const totalCount = results[0].totalCount;
  const pageQueryStr = ` LIMIT `  + pageSize  +  `  OFFSET `  + pageSize  * (pageNum  -  1);
  return [pageQueryStr, totalCount];
}