import express from 'express';
import db from './helpers/mysql';
import relayer from './helpers/relayer';
import { pinJson } from './helpers/ipfs';
import { verify, jsonParse, toJson, sendError, sendSuccess } from './helpers/utils';
import { storeData, getCommentCount, getProposalCommentCount, getSupportCount, checkSafety, hideData} from './helpers/adapters/mysql';
import pkg from '../package.json';
import scheduleCronstyle from './helpers/schedule';
import getBlockNumber from './helpers/block';
import { checkText } from './helpers/green/textSyncScanSample';

scheduleCronstyle();

const network = process.env.NETWORK || 'testnet';
const router = express.Router();

router.get('/', (req, res) => {
  return res.json({
    name: pkg.name,
    network,
    version: pkg.version,
    tag: 'alpha',
    relayer: relayer.address
  });
});

router.get('/drafts', async (req, res) => {
  let query = "SELECT * FROM messages WHERE type = 'draft' AND token = ? AND status <> 2 ORDER BY timestamp DESC";
  // let pagination = await getPagination(req, query, [process.env.ERC20_TOKEN]);
  // query = query + pagination[0];
  let messages = await db.queryAsync(query, [process.env.ERC20_TOKEN]);
  let msgMap = new Map();
  for (var i = 0; i < messages.length; i++) {
    let supCount, comCount;
    await getSupportCount(messages[i].id).then(results => {
      supCount = results[0].supportCount;
    });

    await getCommentCount(messages[i].id).then(results => {
      comCount = results[0].commentCount;
    });
    const metadata = jsonParse(messages[i].metadata);
    msgMap.set(messages[i].id, 
      {
        address: messages[i].address,
        supportCount:supCount,
        commentCount:comCount,
        //totalCount:pagination[1],
        related:messages[i].related,
        msg: {
          version: messages[i].version,
          timestamp: messages[i].timestamp.toString(),
          token: messages[i].token,
          type: messages[i].type,
          payload: jsonParse(messages[i].payload)
        },
        sig: messages[i].sig,
        authorIpfsHash: messages[i].id,
        relayerIpfsHash: metadata.relayer_ipfs_hash
    })
  }
  res.json(Object.fromEntries(msgMap));
});

router.get('/detail/:id', async (req, res) => {
  const { id } = req.params;
  const query = "SELECT * FROM messages WHERE status <> 2 AND token = ? AND id = ?";
  db.queryAsync(query, [process.env.ERC20_TOKEN, id]).then(messages => {
    res.json(Object.fromEntries(
      messages.map(message => {
        const metadata = jsonParse(message.metadata);
        return [message.id, {
          address: message.address,
          msg: {
            version: message.version,
            timestamp: message.timestamp.toString(),
            token: message.token,
            type: message.type,
            payload: jsonParse(message.payload)
          },
          sig: message.sig,
          authorIpfsHash: message.id,
          relayerIpfsHash: metadata.relayer_ipfs_hash
        }];
      })
    ));
  });
});

router.get('/support/:id', async (req, res) => {
  const { id } = req.params;
  const query = `SELECT * FROM messages WHERE type = 'support' AND token = ? AND JSON_EXTRACT(payload, "$.draft") = ? ORDER BY timestamp ASC`;
  db.queryAsync(query, [process.env.ERC20_TOKEN, id]).then(messages => {
    res.json(Object.fromEntries(
      messages.map(message => {
        const metadata = jsonParse(message.metadata);
        return [message.id, {
          address: message.address,
          msg: {
            version: message.version,
            timestamp: message.timestamp.toString(),
            token: message.token,
            type: message.type,
            payload: jsonParse(message.payload)
          },
          sig: message.sig,
          authorIpfsHash: message.id,
          relayerIpfsHash: metadata.relayer_ipfs_hash
        }];
      })
    ));
  });
});


router.get('/comment/:id', async (req, res) => {
  const { id } = req.params;
  const query = `SELECT * FROM messages WHERE type = 'comment' AND token = ? AND (JSON_EXTRACT(payload, "$.draft") = ? or JSON_EXTRACT(payload, "$.proposal") = ?) AND status <> 2 ORDER BY timestamp ASC`;
  db.queryAsync(query, [process.env.ERC20_TOKEN, id, id]).then(messages => {
    res.json(Object.fromEntries(
      messages.map(message => {
        const metadata = jsonParse(message.metadata);
        return [message.id, {
          address: message.address,
          msg: {
            version: message.version,
            timestamp: message.timestamp.toString(),
            token: message.token,
            type: message.type,
            payload: jsonParse(message.payload)
          },
          sig: message.sig,
          authorIpfsHash: message.id,
          relayerIpfsHash: metadata.relayer_ipfs_hash
        }];
      })
    ));
  });
});


router.get('/proposals', async (req, res) => {
  const query = "SELECT * FROM messages WHERE type = 'proposal' AND token = ? AND status <> 2 ORDER BY timestamp DESC";
  let messages = await db.queryAsync(query, [process.env.ERC20_TOKEN]);
  let msgMap = new Map();
  for (var i = 0; i < messages.length; i++) {
    let comCount;
    await getProposalCommentCount(messages[i].id).then(results => {
      comCount = results[0].commentCount;
    });
    const metadata = jsonParse(messages[i].metadata);
    msgMap.set(messages[i].id, 
      {
        address: messages[i].address,
        commentCount:comCount,
        //totalCount:pagination[1],
        related:messages[i].related,
        msg: {
          version: messages[i].version,
          timestamp: messages[i].timestamp.toString(),
          token: messages[i].token,
          type: messages[i].type,
          payload: jsonParse(messages[i].payload)
        },
        sig: messages[i].sig,
        authorIpfsHash: messages[i].id,
        relayerIpfsHash: metadata.relayer_ipfs_hash
    })
  }
  res.json(Object.fromEntries(msgMap));
});

router.get('/vote/:id', async (req, res) => {
  const { id } = req.params;
  const query = `SELECT * FROM messages WHERE type = 'vote' AND token = ? AND JSON_EXTRACT(payload, "$.proposal") = ? ORDER BY timestamp ASC`;
  db.queryAsync(query, [process.env.ERC20_TOKEN, id]).then(messages => {
    res.json(Object.fromEntries(
      messages.map(message => {
        const metadata = jsonParse(message.metadata);
        return [message.id, {
          address: message.address,
          msg: {
            version: message.version,
            timestamp: message.timestamp.toString(),
            token: message.token,
            type: message.type,
            payload: jsonParse(message.payload)
          },
          sig: message.sig,
          authorIpfsHash: message.id,
          relayerIpfsHash: metadata.relayer_ipfs_hash
        }];
      })
    ));
  });
});

router.post('/message', async (req, res) => {
  const body = req.body;
  const msg = jsonParse(body.msg);
  const ts = (Date.now() / 1e3).toFixed();
  // const minBlock = (3600 * 24) / 15;

  if (!body || !body.address || !body.msg || !body.sig)
    return sendError(res, 'wrong message body');

  if (
    Object.keys(msg).length !== 5 ||
    !msg.payload ||
    Object.keys(msg.payload).length === 0
  ) return sendError(res, 'wrong signed message');

  if (!msg.timestamp || typeof msg.timestamp !== 'string' || msg.timestamp > (ts + 30))
    return sendError(res, 'wrong timestamp');

  if (!msg.version || msg.version !== pkg.version)
    return sendError(res, 'wrong version');

  if (!msg.type || ![ 'draft', 'support', 'comment', 'proposal', 'vote'].includes(msg.type))
    return sendError(res, 'wrong message type');

  if (!await verify(body.address, body.msg, body.sig))
    return sendError(res, 'wrong signature');

  let safetyResults = await checkSafety(body.address);
  if(safetyResults[0].safetyCount > process.env.SAFETY_COUNT)
    return sendError(res, '24H limit exceeded');

  if (msg.type === 'proposal' || msg.type === 'draft') {

    //检测内容违规
    let green = await checkText(msg.payload.name + msg.payload.body + msg.payload.choices);
    if(green !== 'pass'){
      return sendError(res, 'wrong content violation');
    }

    let block = await getBlockNumber();
    if(!block[2]){
      return sendError(res, 'wrong snapshot unavailable');
    }
    msg.payload.start = block[0];
    msg.payload.end = block[1];
    msg.payload.snapshot = block[2];
    body.msg = toJson(msg);
    
    if (
      Object.keys(msg.payload).length !== 7 ||
      !msg.payload.choices ||
      msg.payload.choices.length < 2
    ) return sendError(res, 'wrong proposal format');

    if (
      !msg.payload.name ||
      msg.payload.name.length > 256 ||
      !msg.payload.body ||
      msg.payload.body.length > 4e4
    ) return sendError(res, 'wrong proposal size');

    if (
      typeof msg.payload.metadata !== 'object' ||
      toJson(msg.payload.metadata).length > 2e4
    ) return sendError(res, 'wrong proposal metadata');
  }

  if (msg.type === 'vote' || msg.type === 'support' || msg.type === 'comment') {

    //检测内容违规
    if(msg.type === 'comment'){
      if(msg.payload.comment){
        let green = await checkText(msg.payload.comment);
        if(green !== 'pass'){
          return sendError(res, 'wrong content violation');
        }
      }else{
        return sendError(res, ' content cannot be blank');
      }
    }
    
    if (
      (msg.type === 'vote' && !msg.payload.proposal) 
      || (msg.type === 'support' && !msg.payload.draft)
      || (msg.type === 'comment' && !(msg.payload.draft || msg.payload.proposal))
    ) return sendError(res, 'wrong vote format');

    let query, proposals;
    let dataId = msg.payload.draft;
    if(!dataId){
      dataId = msg.payload.proposal;
    }
    query = `SELECT * FROM messages WHERE token = ? AND id = ? AND type in ('draft', 'proposal')`;
    proposals = await db.queryAsync(query, [process.env.ERC20_TOKEN, dataId]);
    if (!proposals[0])
      return sendError(res, 'unknown proposal');
    const payload = jsonParse(proposals[0].payload);
    if (ts > payload.end || payload.start > ts)
      return sendError(res, 'not in voting window');

    if(msg.type === 'vote'){
      query = `SELECT * FROM messages WHERE type = 'vote' AND token = ? AND address = ? AND JSON_EXTRACT(payload, "$.proposal") = ?`;
      proposals = await db.queryAsync(query, [process.env.ERC20_TOKEN, body.address, msg.payload.proposal]);
      if (proposals[0])
        return sendError(res, 'cannot repeat vote');
    }else{
      if(msg.type === 'support'){
        query = `SELECT * FROM messages WHERE type = 'support' AND token = ? AND address = ? AND JSON_EXTRACT(payload, "$.draft") = ?`;
        proposals = await db.queryAsync(query, [process.env.ERC20_TOKEN, body.address, msg.payload.draft]);
        if (proposals[0])
          return sendError(res, 'cannot repeat support');
      }
    }
  }

  const authorIpfsRes = await pinJson(`snapshot/${body.sig}`, {
    address: body.address,
    msg: body.msg,
    sig: body.sig,
    version: '2'
  });

  const relayerSig = await relayer.signMessage(authorIpfsRes);
  const relayerIpfsRes = await pinJson(`snapshot/${relayerSig}`, {
    address: relayer.address,
    msg: authorIpfsRes,
    sig: relayerSig,
    version: '2'
  });

  await storeData(process.env.ERC20_TOKEN, body, authorIpfsRes, relayerIpfsRes);

  return res.json({ ipfsHash: authorIpfsRes });
});

router.post('/delete', async (req, res) => {
  const body = req.body;
  const msg = jsonParse(body.msg);

  if (!body || !body.address || !body.msg || !body.sig)
    return sendError(res, 'wrong message body');

  if (!msg.payload || !msg.payload.dataId)
    return sendError(res, 'wrong message payload');

  if (!msg.type || !['draft', 'comment', 'proposal'].includes(msg.type))
    return sendError(res, 'wrong message type');

  if (!await verify(body.address, body.msg, body.sig))
    return sendError(res, 'wrong signature');

  const query = `SELECT * FROM messages WHERE token = ? AND id = ? AND type = ?`;
  const dataObj = await db.queryAsync(query, [process.env.ERC20_TOKEN, msg.payload.dataId, msg.type]);
  if (!dataObj[0])
    return sendError(res, 'unknown proposal');

  if(dataObj[0].address != body.address && body.address != process.env.ADMIN_ADDRESS)
    return sendError(res, 'permission denied');

  if(dataObj[0].status != 0)
    return sendError(res, 'cannot be changed');

  await hideData(msg.payload.dataId);

  return sendSuccess(res);
})

export default router;
